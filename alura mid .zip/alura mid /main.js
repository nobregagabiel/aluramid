function TocaSomPom(){
    document.querySelector('#som_tecla_pom').play();
}
function TocaSomClap(){
    document.querySelector('#som_tecla_clap').play();
}
function TocaSomTim(){
    document.querySelector('#som_tecla_tim').play();
}

function TocaSomPuff(){
    document.querySelector('#som_tecla_puff').play();
}
function TocaSomSplash(){
    document.querySelector('#som_tecla_splash').play();
}
function TocaSomToim(){
    document.querySelector('#som_tecla_toim').play();
}

function TocaSomPsh(){
    document.querySelector('#som_tecla_Psh').play();
}
function TocaSomTic(){
    document.querySelector('#som_tecla_tic').play();
}
function TocaSomTom(){
    document.querySelector('#som_tecla_tom').play();
}
